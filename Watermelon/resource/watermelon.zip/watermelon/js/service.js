function toBaidu(){
	window.location.href='watermelon://webview?params=%7B%22url%22%3A%22http%3A%2F%2Fwww.baidu.com%22%7D';
}